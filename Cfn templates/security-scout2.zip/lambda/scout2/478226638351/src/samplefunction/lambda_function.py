#!/usr/bin/env python3
"""
Description - This Scritp will get the Today-ec2_findings data from Scout2-History
        bucket for each account and write Findings data to dynamodb table

Update Table    -   <Table Name>

Requrements - python3, Scout2 Report, imported libraries, aws crossaccount role,dynamodb,sns subscription,s3 bucket access

Output - Writing findings data for each rule in to dynamodbTable for each AWS account.

"""
__author__ = "Chenna Vemula,Brian Rossi"
__COPYRIGHT__ = " Copyright 2018 , Caterpillar"
__email__ = " chenna_vemula@cat.com"
__version__ = " 0.0.1-Testing"
import datetime
import json
import os
import boto3
import dateutil
from boto3.dynamodb.conditions import Attr, Key
from botocore.exceptions import ClientError
from dateutil import parser, tz
from dateutil.parser import parse
sts = boto3.client('sts')
ClientSSM = boto3.client('ssm', 'us-east-2')
sns_client = boto3.client('sns')
dynamodb_resource = boto3.resource('dynamodb','us-east-2')
dynamodb_client = boto3.client('dynamodb','us-east-2')  # conection to the dynamo db
update_table_primarykey='Accountid'
update_table_sort_key='Rulename'
service='s3'
BUCKET_NAME = 'ue2-scout2-dev-history'  # replace with your bucket name
def lambda_handler(event, context):
    print("This is just a test")
    return "Success"
