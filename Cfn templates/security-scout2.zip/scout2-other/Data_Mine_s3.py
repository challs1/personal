import json
import pprint
import re
import os
import boto3
from botocore.exceptions import ClientError
#import sendgrid



def mine_data():
    # open the file and load it into json to convert into dictionaries
    directory = os.fsencode("C:\\Users\\ajmera\\Desktop\\accounts\\")
    for file in os.listdir(directory):
        filename = os.fsdecode(file)
        if filename.endswith(".js"):   #if the filename ends with .js thne execute the loop
            print("__________file_name is:  %s" %file)
            with open(directory + file, 'rt') as f:
                next(f)
                content = f.read()
                data = json.loads(content)
            # pprint.pprint(data)
            accnt_ID = data["aws_account_id"]
            print("Account_ID: {}".format(accnt_ID))
            IAM = {}  # dictionary for IAM service
            S3 = {}  # dictionary for s3 service
            bucket_ID = []    # bucket list to store bucket ID reterived from items. 
            iam_exclude = ['iam-assume-role-lacks-external-id-and-mfa', 'iam-ec2-role-without-instances', 'iam-group-with-inline-policies', 
            'iam-inline-group-policy-allows-NotActions', 'iam-inline-group-policy-allows-iam-PassRole', 'iam-inline-group-policy-allows-sts-AssumeRole', 
            'iam-inline-role-policy-allows-NotActions', 'iam-inline-role-policy-allows-iam-PassRole', 'iam-inline-role-policy-allows-sts-AssumeRole', 
            'iam-inline-user-policy-allows-NotActions', 'iam-inline-user-policy-allows-iam-PassRole' ]
            # save list of services.
            service_List = data["service_list"]
            pprint.pprint("Service_List: {}" .format(service_List))
            # check each servies's findings
            i = 0
            while len(service_List) > i:
                try:
                    service = service_List[i]
                    keys = data["services"][service]["findings"]
                except:
                    print(
                        "_____________________%s does not have findings___________________________________" % service)
                    pass

                if (service == "s3"):
                    print("*********************" + service +"*************************")
                    S3[accnt_ID] = {}
                    S3[accnt_ID][service] = {}
                    S3[accnt_ID][service]["problem"] = {}

                    try:
                        for k, v in keys.items():
                            # findings has all the necessary variables needed to be extracted
                            findings = data["services"][service]["findings"][k]
                            if findings["flagged_items"] >= 1:
                                print(k)
                                pprint.pprint(findings["description"])
                                # pprint.pprint(findings["description"])
                                # pprint.pprint(findings["flagged_items"])
                                pprint.pprint(findings["level"])
                                pprint.pprint(findings["items"])
                                pprint.pprint(findings["rationale"])

                                """_______creating a dictionary_______ """
                                S3[accnt_ID][service]["problem"][k] = {}
                                S3[accnt_ID][service]["problem"][k]["Findings"] = {}
                                S3[accnt_ID][service]["problem"][k]["Findings"]["description"] = (findings["description"])
                                S3[accnt_ID][service]["problem"][k]["Findings"]["Items"] = [findings["items"]]
                                S3[accnt_ID][service]["problem"][k]["Findings"]["rationale"] = (findings["rationale"])
                                S3[accnt_ID][service]["problem"][k]["Findings"]["level"] = (findings["level"])
                                S3[accnt_ID][service]["problem"][k]["Findings"]["bucket_info"] = {}

                                bucket_ID = (findings['items'])
                                for x in bucket_ID:
                                    lIdS = re.findall(r"(?<=s\.).*?(?=\.)", x)
                                    for y in lIdS:
                                        bucket_names = data["services"][service]["buckets"][y]["name"]
                                        pprint.pprint(
                                            "Name:" + bucket_names + " id:" + y)
                                        S3.setdefault(accnt_ID, {}).setdefault(service, {}).setdefault("problem",{}).setdefault(k,{}).setdefault("Findings",{}).setdefault("bucket_info",{})[y]= bucket_names      
                                        #find source ip address for users and policies 
                                        Groups_ID = data["services"][service]["buckets"][y]["groups"]
                                        try:
                                            for rand_k, rand_v in Groups_ID.items():
                                                user_ID = data["services"][service]["buckets"][y]["groups"][rand_k]["policies"]
                                                pprint.pprint(
                                                    "aws:SourceIp: " + str(user_ID))

                                                users_ID = data["services"][service]["buckets"][y]["users"][rand_k]["policies"]
                                                pprint.pprint("aws:SourceIp:: " + str(users_ID))
                                        except:
                                            continue# if there is not src ip it will continue
                        #priting the dictionary created            
                        pprint.pprint(S3)

                    except:
                        print("S3 service id: {}  could not be found".format(y))
                        pass

                elif (service == "iam"):
                    print("*********************" + service +"*************************")
                    # for flgageed items
                    iam_findings = data["services"][service]["findings"]
                    for key_iam, key_value in iam_findings.items():
                            iam_config_findings = data["services"][service]["findings"][key_iam]
                            try:
                                if iam_config_findings["flagged_items"] >= 1:
                                    iam_items = iam_config_findings["items"]
                                    print(key_iam)
                                    if key_iam not in iam_exclude:
                                        strip_id = re.findall(r"(?<=s\.).*?(?=\.)", str(iam_items))
                                        """_______creating a dictionary_______ """
                                        IAM[accnt_ID] = {}
                                        IAM[accnt_ID][service] = {}
                                        IAM[accnt_ID][service]["problem"] = {}
                                        IAM[accnt_ID][service]["problem"][key_iam] = {}
                                        IAM[accnt_ID][service]["problem"][key_iam]["Findings"] = {}
                                        IAM[accnt_ID][service]["problem"][key_iam]["Findings"]["description"] = (iam_config_findings["description"])
                                        IAM[accnt_ID][service]["problem"][key_iam]["Findings"]["Items"] = [iam_config_findings["items"]]
                                        IAM[accnt_ID][service]["problem"][key_iam]["Findings"]["rationale"] = (iam_config_findings["rationale"])
                                        IAM[accnt_ID][service]["problem"][key_iam]["Findings"]["level"] = (iam_config_findings["level"])

                                        for znat in strip_id:
                                            try:
                                                # mactch and find the name of policy accroding to found ID in items
                                                iam = data["services"][service]["policies"][znat]["name"]
                                                print("policy" + "id: " +
                                                    znat + "| "+"name: " + iam)
                                                IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("policy", {}) 
                                                IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("policy", {})[znat] = iam
                                            except:
                                                try:
                                                    # if does not belong to policy then look for the name under roles
                                                    iam = data["services"][service]["roles"][znat]["name"]
                                                    print("role: " + "id: " +
                                                        znat + "| "+"name: " + iam)
                                                    IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("roles", {}) 
                                                    IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("roles", {})[znat] = iam
                                                except:
                                                    try:
                                                        for multi_Dom in strip_id:
                                                            iam = data["services"][service]["roles"][multi_Dom]["inline_policies"][znat]["name"]
                                                            print("inline-policy: " +
                                                                znat + "| "+"name: " + iam)
                                                            IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("inline-policy", {}) 
                                                            IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("inline-policy", {})[znat] = iam
                                                    except:
                                                        try:

                                                            iam = data["services"][service]["users"][znat]["name"]
                                                            print("users: " + znat + " | "+"name: " + iam)
                                                            IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("users", {}) 
                                                            IAM.setdefault(accnt_ID,{}).setdefault(service,{}).setdefault("problem", {}).setdefault(key_iam,{}).setdefault("Findings", {}).setdefault("users", {})[znat] = iam
                                                        except:
                                                            continue # if redundant keys then it will continue

                                    else: 
                                        continue  # do not print anything if the key is in exclude list. 
                                #printing IAM dictionary
                                    pprint.pprint(IAM)
                            except:
                                pprint.pprint("Error: "+ str(key_iam))

                i += 1
# """
#
# def send_notificaiton_via_send_grid():
#     client = sendgrid.SendGridClient("SENDGRID_APIKEY")
#     message = sendgrid.Mail()
#
#     message.add_to("test@sendgrid.com")
#     message.set_from("you@youremail.com")
#     message.set_subject("Sending with SendGrid is Fun")
#     message.set_html("and easy to do anywhere, even with Python")
#
#     client.send(message)
# ""
"""
def push_notificaiton(): 
    try: 
        #session = boto3.Session(aws_access_key_id="AKIAJKKVRXLDD6GFO5OQ", aws_secret_access_key="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",region_name="us-east-2")
        sns_client = boto3.client('sns', 
        aws_access_key_id="AKIAJKKVRXLDD6GFO5OQ", 
        aws_secret_access_key="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",
        region_name="us-east-2") #connection to sns. 


        sns_client.publish(
                            TopicArn='arn:aws:sns:us-east-2:997132128247:Scout2_Demo',
                            Message='<h1>This is a test message with HTML </h1> ',
                            Subject='TEST '
                                        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(e.response['ResponseMetadata']['RequestId'])
"""
        
if __name__ == "__main__":
    mine_data()
    #push_notificaiton()
    # send_notificaiton_via_send_grid()
