# 🐛**Scout2@Cat**🐛
**********************************************************************************************************
**This Beta version of Scout2 For Caterpillar Organization**
**********************************************************************************************************
<div align ="center"><img src="https://github.com/ARMAAN7139/Scout2/blob/master/CAT-logo.png"></div>

# Description
**********************************************************************************************************
Scout2 is a security tool that lets AWS administrators assess their environment's security posture. Using the AWS API, Scout2 gathers configuration data for manual inspection and highlights high-risk areas automatically. Rather than pouring through dozens of pages on the web, Scout2 supplies a clear view of the attack surface automatically.

Note: Scout2 is stable and actively maintained, but a number of features and internals may change. As such, please bear with us as we find time to work on, and improve, the tool. Feel free to report a bug, request a new feature, or send a pull request.


## AWS Credentials
**********************************************************************************************************
To run Scout2, you will need valid AWS credentials (e.g Access Key ID and Secret Access Key). The role, or user account, associated with these credentials requires read-only access for all resources in a number of services, including but not limited to CloudTrail, EC2, IAM, RDS, Redshift, and S3.

If you are not sure what permissions to grant, the Scout2-Default IAM policy lists the permissions necessary for a default run of Scout2.

Compliance with AWS' Acceptable Use Policy
Use of Scout2 does not require AWS users to complete and submit the AWS Vulnerability / Penetration Testing Request Form. Scout2 only performs AWS API calls to fetch configuration data and identify security gaps, which is not considered security scanning as it does not impact AWS' network and applications.

## Usage
**********************************************************************************************************
After performing a number of AWS API calls, Scout2 will create a local HTML report and open it in the default browser.


## Python
Scout2 is written in Python and supports the following versions:
**********************************************************************************************************
3.6

⚽⚽⚽⚽⚽⚽⚽⚽⚽⚽⚽🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆⚽⚽⚽⚽⚽⚽⚽⚽⚽⚽⚽
<div align="center"><img src="https://images.cdn.fourfourtwo.com/sites/fourfourtwo.com/files/styles/inline-image/public/spain_banner.png?itok=tZrEotci"></div> 

