#!/bin/bash
export http_proxy="http://172.18.10.246:80"
export https_proxy="http://172.18.10.246:80"
export no_proxy="localhost, .cat.com, 169.254.169.254"
profile=`grep profile .aws/devconfig | awk '{print $2}' | tr -d '] ='`
declare -a array
array=(${profile// /})
service=s3
accounts=`grep role_arn .aws/devconfig | awk '{print $3}' | tr -d '] ='`
i=0
for b in $accounts;
do
        strip=$(echo $b| cut -d':' -f 5)
        echo ${array[i]} $strip
        Scout2 --profile ${array[i]} --ruleset CAT-CIS-Ruleset-s3 --services $service --report-dir /home/ec2-user/efs-scout2/$strip/$service --force --no-browser
        sleep 2
        if [ "${array[i]}" = "default" ]
        then
                sudo aws s3 sync  /home/ec2-user/efs-scout2/$strip/$service  s3://ue2-scout2-dev-history/$strip/$service/latest
                sudo aws s3 cp  /home/ec2-user/efs-scout2/$strip/$service/inc-awsconfig s3://ue2-scout2-dev-history/$strip/$service/$(date +%m-%d-%Y) --recursive
        else
                sudo aws s3 sync  /home/ec2-user/efs-scout2/$strip/$service  s3://ue2-scout2-dev-history/$strip/$service/latest
                sudo aws s3 cp  /home/ec2-user/efs-scout2/$strip/$service/inc-awsconfig   s3://ue2-scout2-dev-history/$strip/$service/$(date +%m-%d-%Y) --recursive
        fi
        i=$((++i))
done

