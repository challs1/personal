#!/bin/bash
export http_proxy="http://172.18.10.246:80"
export https_proxy="http://172.18.10.246:80"
export no_proxy="localhost, .cat.com, 169.254.169.254"
profile=`grep profile .aws/config | awk '{print $2}' | tr -d '] ='`
declare -a array
array=(${profile// /})
accounts=`grep role_arn .aws/config | awk '{print $3}' | tr -d '] ='`
i=0
for b in $accounts;
do
        strip=$(echo $b| cut -d':' -f 5)
        echo ${array[i]} $strip
        Scout2 --profile ${array[i]} --ruleset CAT-CIS-Ruleset.json --report-dir /home/ec2-user/efs-scout2/$strip --force --no-browser
        Scout2 --profile ${array[i]} --ruleset CAT-CIS-Ruleset.json --local --report-dir /home/ec2-user/efs-scout2/$strip --force --no-browser
        sleep 2
        if [ "${array[i]}" = "default" ]
        then
                sudo tail  /home/ec2-user/efs-scout2/$strip/inc-awsconfig/aws_config.js -n +2 | jq .services[].findings >> /home/ec2-user/efs-scout2/$strip/$strip-findings.json
                sudo aws s3 sync  /home/ec2-user/efs-scout2/$strip  s3://ue2-scout2-qa-history/$strip/latest
                sudo aws s3 cp  /home/ec2-user/efs-scout2/$strip  s3://ue2-scout2-qa-history/$strip/$(date +%m-%d-%Y) --recursive
        else
                sudo tail  /home/ec2-user/efs-scout2/$strip/inc-awsconfig/aws_config-${array[i]}.js -n +2 | jq .services[].findings >> /home/ec2-user/efs-scout2/$strip/$strip-findings.json
                sudo aws s3 sync  /home/ec2-user/efs-scout2/$strip  s3://ue2-scout2-qa-history/$strip/latest
                sudo aws s3 cp  /home/ec2-user/efs-scout2/$strip  s3://ue2-scout2-qa-history/$strip/$(date +%m-%d-%Y) --recursive
        fi
        i=$((++i))
done
