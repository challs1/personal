#!/usr/bin/env python3
# coding=utf-8
import os
import boto3, json, time, datetime, sys
from boto3.dynamodb.conditions import Key, Attr
os.environ['http_proxy']="http://172.18.10.246:80"
os.environ['https_proxy']="http://172.18.10.246:80"
os.environ['no_proxy']="localhost, .cat.com, 169.254.169.254"
dynamodb_resource = boto3.resource('dynamodb','us-east-2')
dynamodb_client = boto3.client('dynamodb','us-east-2')
dev_accounts=['413750806156','452253933603','317478934138','308591795231','478226638351','002710387481','799824181982']
accounts_list_table=dynamodb_resource.Table('awsaccounts-crossaccountrole-list')
ac_list_scan = accounts_list_table.scan(ProjectionExpression="AccountID,Alias,CrossAuditRole",FilterExpression=Attr("CrossAuditRole").ne('NotFound') & Attr("Scout2dataS3key").ne('N/A'))
with open("/home/ec2-user/.aws/devconfig",  "w+") as f:
    for item in ac_list_scan['Items']:
        if item['AccountID'] =='478226638351':
            f.write("[profile default] \n")
            f.write("role_arn =  "+item['CrossAuditRole'] +'\n')
            f.write("source_profile = default \n")
        else:
            if item['AccountID'] in dev_accounts:
                f.write('[profile'+'    '+item['Alias']+']\n')
                f.write("role_arn =  "+item['CrossAuditRole'] +'\n')
                f.write("source_profile = default \n")
    f.close()
